﻿namespace Cizar.ERP
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.حسابداریمالیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیاولیهToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.گروهبندیحسابهاToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.کلومعینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سندافتتاحیهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیحسابتفصیلیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سندحسابداریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستاسنادToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.صورتحسابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ترازآزمایشیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سودوزیانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ترازنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بستنحسابهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سندسودوزیانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سنداختتامیهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پشتیبانیوامنیتToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتحسابداریمالیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خزانهداریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیاولیهToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیبانکToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیصندوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیتنخواهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیدستهچکToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عملیاتپرداختToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عملیاتدریافتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عملیاتپرداختودریافتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.پشتیبانیوامنیتToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتخزانهداریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خریدوفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیاولیهToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.گروهبندیکالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیواحدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گروهبندیکالاToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.تعیینسرفصلهایحسابداریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.برگشتازخریدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.برگشتازفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.پشتیبانیوامنیتToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتخریدوفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حقوقودستمزدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیاولیهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیمحاسبهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیبانکToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جدولمالیاتیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عناوینشغلیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیمحاسبهToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیپرسنلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مبانیحقوقیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعریفمزایاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعریفوامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعریفمرخصیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حکمحقوقیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ردیفپیمانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حکمحقوقیToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.عملیاتماهانهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتوامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتبیمهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتکارکردToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.محاسبهحقوقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.محاسبهمزایایپایانسالToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فیشحقوقیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستحقوقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستبانکToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستبیمهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستمالیاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خلاصهگزارشحقوقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اطلاعاتپرسنلیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستخامکارکردToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشکارکردToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشمرخصیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پشتیبانیوامنیتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تهیهپشتیبانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بازیابیپشتیبانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تنظیماتحقوقودستمزدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعریفمبالغمزایایسالیانهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفینحوهمحاسبهمالیاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.معرفیضرایببیمهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجازسیستمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlQuickAccess = new System.Windows.Forms.Panel();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.btnSide_Alarm = new System.Windows.Forms.Button();
            this.btnSide_Markaz = new System.Windows.Forms.Button();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.btnSide_Logout = new System.Windows.Forms.Button();
            this.btnSide_Setting = new System.Windows.Forms.Button();
            this.btnSide_Security = new System.Windows.Forms.Button();
            this.btnSide_Years = new System.Windows.Forms.Button();
            this.btnSide_Company = new System.Windows.Forms.Button();
            this.lblTitle = new DevComponents.DotNetBar.LabelX();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.pnlQuickAccess.SuspendLayout();
            this.pnlSidebar.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("A Iranian Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.حسابداریمالیToolStripMenuItem,
            this.خزانهداریToolStripMenuItem,
            this.خریدوفروشToolStripMenuItem,
            this.حقوقودستمزدToolStripMenuItem,
            this.خروجازسیستمToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 4, 0, 4);
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1200, 27);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // حسابداریمالیToolStripMenuItem
            // 
            this.حسابداریمالیToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مبانیاولیهToolStripMenuItem2,
            this.سندافتتاحیهToolStripMenuItem,
            this.معرفیحسابتفصیلیToolStripMenuItem,
            this.سندحسابداریToolStripMenuItem,
            this.لیستاسنادToolStripMenuItem,
            this.گزارشاتToolStripMenuItem1,
            this.بستنحسابهاToolStripMenuItem,
            this.پشتیبانیوامنیتToolStripMenuItem1,
            this.تنظیماتحسابداریمالیToolStripMenuItem});
            this.حسابداریمالیToolStripMenuItem.Name = "حسابداریمالیToolStripMenuItem";
            this.حسابداریمالیToolStripMenuItem.Size = new System.Drawing.Size(109, 19);
            this.حسابداریمالیToolStripMenuItem.Text = "حسابداری مالی";
            // 
            // مبانیاولیهToolStripMenuItem2
            // 
            this.مبانیاولیهToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.گروهبندیحسابهاToolStripMenuItem1,
            this.کلومعینToolStripMenuItem});
            this.مبانیاولیهToolStripMenuItem2.Name = "مبانیاولیهToolStripMenuItem2";
            this.مبانیاولیهToolStripMenuItem2.Size = new System.Drawing.Size(216, 22);
            this.مبانیاولیهToolStripMenuItem2.Text = "مبانی اولیه";
            // 
            // گروهبندیحسابهاToolStripMenuItem1
            // 
            this.گروهبندیحسابهاToolStripMenuItem1.Name = "گروهبندیحسابهاToolStripMenuItem1";
            this.گروهبندیحسابهاToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.گروهبندیحسابهاToolStripMenuItem1.Text = "گروه بندی حسابها";
            // 
            // کلومعینToolStripMenuItem
            // 
            this.کلومعینToolStripMenuItem.Name = "کلومعینToolStripMenuItem";
            this.کلومعینToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.کلومعینToolStripMenuItem.Text = "کل و معین";
            // 
            // سندافتتاحیهToolStripMenuItem
            // 
            this.سندافتتاحیهToolStripMenuItem.Name = "سندافتتاحیهToolStripMenuItem";
            this.سندافتتاحیهToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.سندافتتاحیهToolStripMenuItem.Text = "سند افتتاحیه";
            // 
            // معرفیحسابتفصیلیToolStripMenuItem
            // 
            this.معرفیحسابتفصیلیToolStripMenuItem.Name = "معرفیحسابتفصیلیToolStripMenuItem";
            this.معرفیحسابتفصیلیToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.معرفیحسابتفصیلیToolStripMenuItem.Text = "حساب تفصیلی";
            // 
            // سندحسابداریToolStripMenuItem
            // 
            this.سندحسابداریToolStripMenuItem.Name = "سندحسابداریToolStripMenuItem";
            this.سندحسابداریToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.سندحسابداریToolStripMenuItem.Text = "سند حسابداری";
            // 
            // لیستاسنادToolStripMenuItem
            // 
            this.لیستاسنادToolStripMenuItem.Name = "لیستاسنادToolStripMenuItem";
            this.لیستاسنادToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.لیستاسنادToolStripMenuItem.Text = "لیست اسناد";
            // 
            // گزارشاتToolStripMenuItem1
            // 
            this.گزارشاتToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.صورتحسابToolStripMenuItem,
            this.ترازآزمایشیToolStripMenuItem,
            this.سودوزیانToolStripMenuItem,
            this.ترازنامهToolStripMenuItem});
            this.گزارشاتToolStripMenuItem1.Name = "گزارشاتToolStripMenuItem1";
            this.گزارشاتToolStripMenuItem1.Size = new System.Drawing.Size(216, 22);
            this.گزارشاتToolStripMenuItem1.Text = "گزارشات";
            // 
            // صورتحسابToolStripMenuItem
            // 
            this.صورتحسابToolStripMenuItem.Name = "صورتحسابToolStripMenuItem";
            this.صورتحسابToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.صورتحسابToolStripMenuItem.Text = "صورتحساب";
            // 
            // ترازآزمایشیToolStripMenuItem
            // 
            this.ترازآزمایشیToolStripMenuItem.Name = "ترازآزمایشیToolStripMenuItem";
            this.ترازآزمایشیToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.ترازآزمایشیToolStripMenuItem.Text = "تراز آزمایشی";
            // 
            // سودوزیانToolStripMenuItem
            // 
            this.سودوزیانToolStripMenuItem.Name = "سودوزیانToolStripMenuItem";
            this.سودوزیانToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.سودوزیانToolStripMenuItem.Text = "سود و زیان";
            // 
            // ترازنامهToolStripMenuItem
            // 
            this.ترازنامهToolStripMenuItem.Name = "ترازنامهToolStripMenuItem";
            this.ترازنامهToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.ترازنامهToolStripMenuItem.Text = "ترازنامه";
            // 
            // بستنحسابهاToolStripMenuItem
            // 
            this.بستنحسابهاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.سندسودوزیانToolStripMenuItem,
            this.سنداختتامیهToolStripMenuItem});
            this.بستنحسابهاToolStripMenuItem.Name = "بستنحسابهاToolStripMenuItem";
            this.بستنحسابهاToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.بستنحسابهاToolStripMenuItem.Text = "بستن حسابها";
            // 
            // سندسودوزیانToolStripMenuItem
            // 
            this.سندسودوزیانToolStripMenuItem.Name = "سندسودوزیانToolStripMenuItem";
            this.سندسودوزیانToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.سندسودوزیانToolStripMenuItem.Text = "سند سود و زیان";
            // 
            // سنداختتامیهToolStripMenuItem
            // 
            this.سنداختتامیهToolStripMenuItem.Name = "سنداختتامیهToolStripMenuItem";
            this.سنداختتامیهToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.سنداختتامیهToolStripMenuItem.Text = "سند اختتامیه";
            // 
            // پشتیبانیوامنیتToolStripMenuItem1
            // 
            this.پشتیبانیوامنیتToolStripMenuItem1.Name = "پشتیبانیوامنیتToolStripMenuItem1";
            this.پشتیبانیوامنیتToolStripMenuItem1.Size = new System.Drawing.Size(216, 22);
            this.پشتیبانیوامنیتToolStripMenuItem1.Text = "پشتیبانی و امنیت";
            // 
            // تنظیماتحسابداریمالیToolStripMenuItem
            // 
            this.تنظیماتحسابداریمالیToolStripMenuItem.Name = "تنظیماتحسابداریمالیToolStripMenuItem";
            this.تنظیماتحسابداریمالیToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.تنظیماتحسابداریمالیToolStripMenuItem.Text = "تنظیمات حسابداری مالی";
            // 
            // خزانهداریToolStripMenuItem
            // 
            this.خزانهداریToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مبانیاولیهToolStripMenuItem1,
            this.عملیاتپرداختToolStripMenuItem,
            this.عملیاتدریافتToolStripMenuItem,
            this.عملیاتپرداختودریافتToolStripMenuItem,
            this.گزارشاتToolStripMenuItem2,
            this.پشتیبانیوامنیتToolStripMenuItem2,
            this.تنظیماتخزانهداریToolStripMenuItem});
            this.خزانهداریToolStripMenuItem.Name = "خزانهداریToolStripMenuItem";
            this.خزانهداریToolStripMenuItem.Size = new System.Drawing.Size(84, 19);
            this.خزانهداریToolStripMenuItem.Text = "خزانه داری";
            // 
            // مبانیاولیهToolStripMenuItem1
            // 
            this.مبانیاولیهToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.معرفیبانکToolStripMenuItem1,
            this.معرفیصندوToolStripMenuItem,
            this.معرفیتنخواهToolStripMenuItem,
            this.معرفیدستهچکToolStripMenuItem});
            this.مبانیاولیهToolStripMenuItem1.Name = "مبانیاولیهToolStripMenuItem1";
            this.مبانیاولیهToolStripMenuItem1.Size = new System.Drawing.Size(191, 22);
            this.مبانیاولیهToolStripMenuItem1.Text = "مبانی اولیه";
            // 
            // معرفیبانکToolStripMenuItem1
            // 
            this.معرفیبانکToolStripMenuItem1.Name = "معرفیبانکToolStripMenuItem1";
            this.معرفیبانکToolStripMenuItem1.Size = new System.Drawing.Size(174, 22);
            this.معرفیبانکToolStripMenuItem1.Text = "معرفی بانک";
            // 
            // معرفیصندوToolStripMenuItem
            // 
            this.معرفیصندوToolStripMenuItem.Name = "معرفیصندوToolStripMenuItem";
            this.معرفیصندوToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.معرفیصندوToolStripMenuItem.Text = "معرفی صندوق";
            // 
            // معرفیتنخواهToolStripMenuItem
            // 
            this.معرفیتنخواهToolStripMenuItem.Name = "معرفیتنخواهToolStripMenuItem";
            this.معرفیتنخواهToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.معرفیتنخواهToolStripMenuItem.Text = "معرفی تنخواه";
            // 
            // معرفیدستهچکToolStripMenuItem
            // 
            this.معرفیدستهچکToolStripMenuItem.Name = "معرفیدستهچکToolStripMenuItem";
            this.معرفیدستهچکToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.معرفیدستهچکToolStripMenuItem.Text = "معرفی دسته چک";
            // 
            // عملیاتپرداختToolStripMenuItem
            // 
            this.عملیاتپرداختToolStripMenuItem.Name = "عملیاتپرداختToolStripMenuItem";
            this.عملیاتپرداختToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.عملیاتپرداختToolStripMenuItem.Text = "عملیات پرداخت";
            // 
            // عملیاتدریافتToolStripMenuItem
            // 
            this.عملیاتدریافتToolStripMenuItem.Name = "عملیاتدریافتToolStripMenuItem";
            this.عملیاتدریافتToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.عملیاتدریافتToolStripMenuItem.Text = "عملیات دریافت";
            // 
            // عملیاتپرداختودریافتToolStripMenuItem
            // 
            this.عملیاتپرداختودریافتToolStripMenuItem.Name = "عملیاتپرداختودریافتToolStripMenuItem";
            this.عملیاتپرداختودریافتToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.عملیاتپرداختودریافتToolStripMenuItem.Text = "عملیات چندگانه";
            // 
            // گزارشاتToolStripMenuItem2
            // 
            this.گزارشاتToolStripMenuItem2.Name = "گزارشاتToolStripMenuItem2";
            this.گزارشاتToolStripMenuItem2.Size = new System.Drawing.Size(191, 22);
            this.گزارشاتToolStripMenuItem2.Text = "گزارشات";
            // 
            // پشتیبانیوامنیتToolStripMenuItem2
            // 
            this.پشتیبانیوامنیتToolStripMenuItem2.Name = "پشتیبانیوامنیتToolStripMenuItem2";
            this.پشتیبانیوامنیتToolStripMenuItem2.Size = new System.Drawing.Size(191, 22);
            this.پشتیبانیوامنیتToolStripMenuItem2.Text = "پشتیبانی و امنیت";
            // 
            // تنظیماتخزانهداریToolStripMenuItem
            // 
            this.تنظیماتخزانهداریToolStripMenuItem.Name = "تنظیماتخزانهداریToolStripMenuItem";
            this.تنظیماتخزانهداریToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.تنظیماتخزانهداریToolStripMenuItem.Text = "تنظیمات خزانه داری";
            // 
            // خریدوفروشToolStripMenuItem
            // 
            this.خریدوفروشToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مبانیاولیهToolStripMenuItem3,
            this.فاکتوToolStripMenuItem,
            this.برگشتازخریدToolStripMenuItem,
            this.فروشToolStripMenuItem,
            this.برگشتازفروشToolStripMenuItem,
            this.گزارشاتToolStripMenuItem3,
            this.پشتیبانیوامنیتToolStripMenuItem3,
            this.تنظیماتخریدوفروشToolStripMenuItem});
            this.خریدوفروشToolStripMenuItem.Name = "خریدوفروشToolStripMenuItem";
            this.خریدوفروشToolStripMenuItem.Size = new System.Drawing.Size(101, 19);
            this.خریدوفروشToolStripMenuItem.Text = "خرید و فروش";
            // 
            // مبانیاولیهToolStripMenuItem3
            // 
            this.مبانیاولیهToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.گروهبندیکالاToolStripMenuItem,
            this.معرفیواحدToolStripMenuItem,
            this.گروهبندیکالاToolStripMenuItem1,
            this.تعیینسرفصلهایحسابداریToolStripMenuItem});
            this.مبانیاولیهToolStripMenuItem3.Name = "مبانیاولیهToolStripMenuItem3";
            this.مبانیاولیهToolStripMenuItem3.Size = new System.Drawing.Size(208, 22);
            this.مبانیاولیهToolStripMenuItem3.Text = "مبانی اولیه";
            // 
            // گروهبندیکالاToolStripMenuItem
            // 
            this.گروهبندیکالاToolStripMenuItem.Name = "گروهبندیکالاToolStripMenuItem";
            this.گروهبندیکالاToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.گروهبندیکالاToolStripMenuItem.Text = "معرفی انبار";
            // 
            // معرفیواحدToolStripMenuItem
            // 
            this.معرفیواحدToolStripMenuItem.Name = "معرفیواحدToolStripMenuItem";
            this.معرفیواحدToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.معرفیواحدToolStripMenuItem.Text = "معرفی واحد";
            // 
            // گروهبندیکالاToolStripMenuItem1
            // 
            this.گروهبندیکالاToolStripMenuItem1.Name = "گروهبندیکالاToolStripMenuItem1";
            this.گروهبندیکالاToolStripMenuItem1.Size = new System.Drawing.Size(235, 22);
            this.گروهبندیکالاToolStripMenuItem1.Text = "گروه بندی کالا";
            // 
            // تعیینسرفصلهایحسابداریToolStripMenuItem
            // 
            this.تعیینسرفصلهایحسابداریToolStripMenuItem.Name = "تعیینسرفصلهایحسابداریToolStripMenuItem";
            this.تعیینسرفصلهایحسابداریToolStripMenuItem.Size = new System.Drawing.Size(235, 22);
            this.تعیینسرفصلهایحسابداریToolStripMenuItem.Text = "تعیین سرفصلهای حسابداری";
            // 
            // فاکتوToolStripMenuItem
            // 
            this.فاکتوToolStripMenuItem.Name = "فاکتوToolStripMenuItem";
            this.فاکتوToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.فاکتوToolStripMenuItem.Text = "فاکتور خرید";
            // 
            // برگشتازخریدToolStripMenuItem
            // 
            this.برگشتازخریدToolStripMenuItem.Name = "برگشتازخریدToolStripMenuItem";
            this.برگشتازخریدToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.برگشتازخریدToolStripMenuItem.Text = "برگشت از خرید";
            // 
            // فروشToolStripMenuItem
            // 
            this.فروشToolStripMenuItem.Name = "فروشToolStripMenuItem";
            this.فروشToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.فروشToolStripMenuItem.Text = "فروش";
            // 
            // برگشتازفروشToolStripMenuItem
            // 
            this.برگشتازفروشToolStripMenuItem.Name = "برگشتازفروشToolStripMenuItem";
            this.برگشتازفروشToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.برگشتازفروشToolStripMenuItem.Text = "برگشت از فروش";
            // 
            // گزارشاتToolStripMenuItem3
            // 
            this.گزارشاتToolStripMenuItem3.Name = "گزارشاتToolStripMenuItem3";
            this.گزارشاتToolStripMenuItem3.Size = new System.Drawing.Size(208, 22);
            this.گزارشاتToolStripMenuItem3.Text = "گزارشات";
            // 
            // پشتیبانیوامنیتToolStripMenuItem3
            // 
            this.پشتیبانیوامنیتToolStripMenuItem3.Name = "پشتیبانیوامنیتToolStripMenuItem3";
            this.پشتیبانیوامنیتToolStripMenuItem3.Size = new System.Drawing.Size(208, 22);
            this.پشتیبانیوامنیتToolStripMenuItem3.Text = "پشتیبانی و امنیت";
            // 
            // تنظیماتخریدوفروشToolStripMenuItem
            // 
            this.تنظیماتخریدوفروشToolStripMenuItem.Name = "تنظیماتخریدوفروشToolStripMenuItem";
            this.تنظیماتخریدوفروشToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.تنظیماتخریدوفروشToolStripMenuItem.Text = "تنظیمات خرید و فروش";
            // 
            // حقوقودستمزدToolStripMenuItem
            // 
            this.حقوقودستمزدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مبانیاولیهToolStripMenuItem,
            this.مبانیحقوقیToolStripMenuItem,
            this.عملیاتماهانهToolStripMenuItem,
            this.گزارشاتToolStripMenuItem,
            this.پشتیبانیوامنیتToolStripMenuItem,
            this.تنظیماتحقوقودستمزدToolStripMenuItem});
            this.حقوقودستمزدToolStripMenuItem.Name = "حقوقودستمزدToolStripMenuItem";
            this.حقوقودستمزدToolStripMenuItem.Size = new System.Drawing.Size(113, 19);
            this.حقوقودستمزدToolStripMenuItem.Text = "حقوق و دستمزد";
            // 
            // مبانیاولیهToolStripMenuItem
            // 
            this.مبانیاولیهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مبانیمحاسبهToolStripMenuItem,
            this.معرفیبانکToolStripMenuItem,
            this.جدولمالیاتیToolStripMenuItem,
            this.عناوینشغلیToolStripMenuItem,
            this.مبانیمحاسبهToolStripMenuItem2,
            this.معرفیپرسنلToolStripMenuItem});
            this.مبانیاولیهToolStripMenuItem.Name = "مبانیاولیهToolStripMenuItem";
            this.مبانیاولیهToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.مبانیاولیهToolStripMenuItem.Text = "مبانی اولیه";
            // 
            // مبانیمحاسبهToolStripMenuItem
            // 
            this.مبانیمحاسبهToolStripMenuItem.Name = "مبانیمحاسبهToolStripMenuItem";
            this.مبانیمحاسبهToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.مبانیمحاسبهToolStripMenuItem.Text = "معرفی کارگاه";
            // 
            // معرفیبانکToolStripMenuItem
            // 
            this.معرفیبانکToolStripMenuItem.Name = "معرفیبانکToolStripMenuItem";
            this.معرفیبانکToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.معرفیبانکToolStripMenuItem.Text = "معرفی بانک";
            // 
            // جدولمالیاتیToolStripMenuItem
            // 
            this.جدولمالیاتیToolStripMenuItem.Name = "جدولمالیاتیToolStripMenuItem";
            this.جدولمالیاتیToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.جدولمالیاتیToolStripMenuItem.Text = "جدول مالیاتی";
            // 
            // عناوینشغلیToolStripMenuItem
            // 
            this.عناوینشغلیToolStripMenuItem.Name = "عناوینشغلیToolStripMenuItem";
            this.عناوینشغلیToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.عناوینشغلیToolStripMenuItem.Text = "عناوین شغلی";
            // 
            // مبانیمحاسبهToolStripMenuItem2
            // 
            this.مبانیمحاسبهToolStripMenuItem2.Name = "مبانیمحاسبهToolStripMenuItem2";
            this.مبانیمحاسبهToolStripMenuItem2.Size = new System.Drawing.Size(153, 22);
            this.مبانیمحاسبهToolStripMenuItem2.Text = "مبانی محاسبه";
            // 
            // معرفیپرسنلToolStripMenuItem
            // 
            this.معرفیپرسنلToolStripMenuItem.Name = "معرفیپرسنلToolStripMenuItem";
            this.معرفیپرسنلToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.معرفیپرسنلToolStripMenuItem.Text = "معرفی پرسنل";
            // 
            // مبانیحقوقیToolStripMenuItem
            // 
            this.مبانیحقوقیToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعریفمزایاToolStripMenuItem,
            this.تعریفوامToolStripMenuItem,
            this.تعریفمرخصیToolStripMenuItem,
            this.حکمحقوقیToolStripMenuItem,
            this.ردیفپیمانToolStripMenuItem,
            this.حکمحقوقیToolStripMenuItem1});
            this.مبانیحقوقیToolStripMenuItem.Name = "مبانیحقوقیToolStripMenuItem";
            this.مبانیحقوقیToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.مبانیحقوقیToolStripMenuItem.Text = "مبانی حقوقی";
            // 
            // تعریفمزایاToolStripMenuItem
            // 
            this.تعریفمزایاToolStripMenuItem.Name = "تعریفمزایاToolStripMenuItem";
            this.تعریفمزایاToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.تعریفمزایاToolStripMenuItem.Text = "معرفی مزایا";
            // 
            // تعریفوامToolStripMenuItem
            // 
            this.تعریفوامToolStripMenuItem.Name = "تعریفوامToolStripMenuItem";
            this.تعریفوامToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.تعریفوامToolStripMenuItem.Text = "معرفی وام";
            // 
            // تعریفمرخصیToolStripMenuItem
            // 
            this.تعریفمرخصیToolStripMenuItem.Name = "تعریفمرخصیToolStripMenuItem";
            this.تعریفمرخصیToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.تعریفمرخصیToolStripMenuItem.Text = "معرفی مرخصی";
            // 
            // حکمحقوقیToolStripMenuItem
            // 
            this.حکمحقوقیToolStripMenuItem.Name = "حکمحقوقیToolStripMenuItem";
            this.حکمحقوقیToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.حکمحقوقیToolStripMenuItem.Text = "معرفی بیمه";
            // 
            // ردیفپیمانToolStripMenuItem
            // 
            this.ردیفپیمانToolStripMenuItem.Name = "ردیفپیمانToolStripMenuItem";
            this.ردیفپیمانToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.ردیفپیمانToolStripMenuItem.Text = "ردیف پیمان";
            // 
            // حکمحقوقیToolStripMenuItem1
            // 
            this.حکمحقوقیToolStripMenuItem1.Name = "حکمحقوقیToolStripMenuItem1";
            this.حکمحقوقیToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.حکمحقوقیToolStripMenuItem1.Text = "حکم حقوقی";
            // 
            // عملیاتماهانهToolStripMenuItem
            // 
            this.عملیاتماهانهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتوامToolStripMenuItem,
            this.ثبتبیمهToolStripMenuItem,
            this.ثبتکارکردToolStripMenuItem,
            this.محاسبهحقوقToolStripMenuItem,
            this.محاسبهمزایایپایانسالToolStripMenuItem});
            this.عملیاتماهانهToolStripMenuItem.Name = "عملیاتماهانهToolStripMenuItem";
            this.عملیاتماهانهToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.عملیاتماهانهToolStripMenuItem.Text = "عملیات ماهانه";
            // 
            // ثبتوامToolStripMenuItem
            // 
            this.ثبتوامToolStripMenuItem.Name = "ثبتوامToolStripMenuItem";
            this.ثبتوامToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ثبتوامToolStripMenuItem.Text = "ثبت وام";
            // 
            // ثبتبیمهToolStripMenuItem
            // 
            this.ثبتبیمهToolStripMenuItem.Name = "ثبتبیمهToolStripMenuItem";
            this.ثبتبیمهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ثبتبیمهToolStripMenuItem.Text = "ثبت بیمه";
            // 
            // ثبتکارکردToolStripMenuItem
            // 
            this.ثبتکارکردToolStripMenuItem.Name = "ثبتکارکردToolStripMenuItem";
            this.ثبتکارکردToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ثبتکارکردToolStripMenuItem.Text = "ثبت کارکرد";
            // 
            // محاسبهحقوقToolStripMenuItem
            // 
            this.محاسبهحقوقToolStripMenuItem.Name = "محاسبهحقوقToolStripMenuItem";
            this.محاسبهحقوقToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.محاسبهحقوقToolStripMenuItem.Text = "محاسبه حقوق";
            // 
            // محاسبهمزایایپایانسالToolStripMenuItem
            // 
            this.محاسبهمزایایپایانسالToolStripMenuItem.Name = "محاسبهمزایایپایانسالToolStripMenuItem";
            this.محاسبهمزایایپایانسالToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.محاسبهمزایایپایانسالToolStripMenuItem.Text = "محاسبه مزایای پایان سال";
            // 
            // گزارشاتToolStripMenuItem
            // 
            this.گزارشاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فیشحقوقیToolStripMenuItem,
            this.لیستحقوقToolStripMenuItem,
            this.لیستبانکToolStripMenuItem,
            this.لیستبیمهToolStripMenuItem,
            this.لیستمالیاتToolStripMenuItem,
            this.خلاصهگزارشحقوقToolStripMenuItem,
            this.اطلاعاتپرسنلیToolStripMenuItem,
            this.لیستخامکارکردToolStripMenuItem,
            this.گزارشکارکردToolStripMenuItem,
            this.گزارشمرخصیToolStripMenuItem});
            this.گزارشاتToolStripMenuItem.Name = "گزارشاتToolStripMenuItem";
            this.گزارشاتToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.گزارشاتToolStripMenuItem.Text = "گزارشات";
            // 
            // فیشحقوقیToolStripMenuItem
            // 
            this.فیشحقوقیToolStripMenuItem.Name = "فیشحقوقیToolStripMenuItem";
            this.فیشحقوقیToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.فیشحقوقیToolStripMenuItem.Text = "فیش حقوقی";
            // 
            // لیستحقوقToolStripMenuItem
            // 
            this.لیستحقوقToolStripMenuItem.Name = "لیستحقوقToolStripMenuItem";
            this.لیستحقوقToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.لیستحقوقToolStripMenuItem.Text = "لیست حقوق";
            // 
            // لیستبانکToolStripMenuItem
            // 
            this.لیستبانکToolStripMenuItem.Name = "لیستبانکToolStripMenuItem";
            this.لیستبانکToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.لیستبانکToolStripMenuItem.Text = "لیست بانک";
            // 
            // لیستبیمهToolStripMenuItem
            // 
            this.لیستبیمهToolStripMenuItem.Name = "لیستبیمهToolStripMenuItem";
            this.لیستبیمهToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.لیستبیمهToolStripMenuItem.Text = "لیست بیمه";
            // 
            // لیستمالیاتToolStripMenuItem
            // 
            this.لیستمالیاتToolStripMenuItem.Name = "لیستمالیاتToolStripMenuItem";
            this.لیستمالیاتToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.لیستمالیاتToolStripMenuItem.Text = "لیست مالیات";
            // 
            // خلاصهگزارشحقوقToolStripMenuItem
            // 
            this.خلاصهگزارشحقوقToolStripMenuItem.Name = "خلاصهگزارشحقوقToolStripMenuItem";
            this.خلاصهگزارشحقوقToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.خلاصهگزارشحقوقToolStripMenuItem.Text = "خلاصه گزارش حقوق";
            // 
            // اطلاعاتپرسنلیToolStripMenuItem
            // 
            this.اطلاعاتپرسنلیToolStripMenuItem.Name = "اطلاعاتپرسنلیToolStripMenuItem";
            this.اطلاعاتپرسنلیToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.اطلاعاتپرسنلیToolStripMenuItem.Text = "اطلاعات پرسنلی";
            // 
            // لیستخامکارکردToolStripMenuItem
            // 
            this.لیستخامکارکردToolStripMenuItem.Name = "لیستخامکارکردToolStripMenuItem";
            this.لیستخامکارکردToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.لیستخامکارکردToolStripMenuItem.Text = "لیست خام کارکرد";
            // 
            // گزارشکارکردToolStripMenuItem
            // 
            this.گزارشکارکردToolStripMenuItem.Name = "گزارشکارکردToolStripMenuItem";
            this.گزارشکارکردToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.گزارشکارکردToolStripMenuItem.Text = "گزارش کارکرد ";
            // 
            // گزارشمرخصیToolStripMenuItem
            // 
            this.گزارشمرخصیToolStripMenuItem.Name = "گزارشمرخصیToolStripMenuItem";
            this.گزارشمرخصیToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.گزارشمرخصیToolStripMenuItem.Text = "گزارش مرخصی";
            // 
            // پشتیبانیوامنیتToolStripMenuItem
            // 
            this.پشتیبانیوامنیتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تهیهپشتیبانToolStripMenuItem,
            this.بازیابیپشتیبانToolStripMenuItem});
            this.پشتیبانیوامنیتToolStripMenuItem.Name = "پشتیبانیوامنیتToolStripMenuItem";
            this.پشتیبانیوامنیتToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.پشتیبانیوامنیتToolStripMenuItem.Text = "پشتیبانی و امنیت";
            // 
            // تهیهپشتیبانToolStripMenuItem
            // 
            this.تهیهپشتیبانToolStripMenuItem.Name = "تهیهپشتیبانToolStripMenuItem";
            this.تهیهپشتیبانToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.تهیهپشتیبانToolStripMenuItem.Text = "تهیه پشتیبان";
            // 
            // بازیابیپشتیبانToolStripMenuItem
            // 
            this.بازیابیپشتیبانToolStripMenuItem.Name = "بازیابیپشتیبانToolStripMenuItem";
            this.بازیابیپشتیبانToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.بازیابیپشتیبانToolStripMenuItem.Text = "بازیابی پشتیبان";
            // 
            // تنظیماتحقوقودستمزدToolStripMenuItem
            // 
            this.تنظیماتحقوقودستمزدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعریفمبالغمزایایسالیانهToolStripMenuItem,
            this.معرفینحوهمحاسبهمالیاتToolStripMenuItem,
            this.معرفیضرایببیمهToolStripMenuItem});
            this.تنظیماتحقوقودستمزدToolStripMenuItem.Name = "تنظیماتحقوقودستمزدToolStripMenuItem";
            this.تنظیماتحقوقودستمزدToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.تنظیماتحقوقودستمزدToolStripMenuItem.Text = "تنظیمات حقوق";
            // 
            // تعریفمبالغمزایایسالیانهToolStripMenuItem
            // 
            this.تعریفمبالغمزایایسالیانهToolStripMenuItem.Name = "تعریفمبالغمزایایسالیانهToolStripMenuItem";
            this.تعریفمبالغمزایایسالیانهToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.تعریفمبالغمزایایسالیانهToolStripMenuItem.Text = "معرفی مبالغ مزایای سالیانه";
            // 
            // معرفینحوهمحاسبهمالیاتToolStripMenuItem
            // 
            this.معرفینحوهمحاسبهمالیاتToolStripMenuItem.Name = "معرفینحوهمحاسبهمالیاتToolStripMenuItem";
            this.معرفینحوهمحاسبهمالیاتToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.معرفینحوهمحاسبهمالیاتToolStripMenuItem.Text = "معرفی نحوه محاسبه مالیات";
            // 
            // معرفیضرایببیمهToolStripMenuItem
            // 
            this.معرفیضرایببیمهToolStripMenuItem.Name = "معرفیضرایببیمهToolStripMenuItem";
            this.معرفیضرایببیمهToolStripMenuItem.Size = new System.Drawing.Size(233, 22);
            this.معرفیضرایببیمهToolStripMenuItem.Text = "معرفی ضرایب بیمه";
            // 
            // خروجازسیستمToolStripMenuItem
            // 
            this.خروجازسیستمToolStripMenuItem.Name = "خروجازسیستمToolStripMenuItem";
            this.خروجازسیستمToolStripMenuItem.Size = new System.Drawing.Size(114, 19);
            this.خروجازسیستمToolStripMenuItem.Text = "خروج از سیستم";
            // 
            // pnlQuickAccess
            // 
            this.pnlQuickAccess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            this.pnlQuickAccess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlQuickAccess.Controls.Add(this.comboBox1);
            this.pnlQuickAccess.Controls.Add(this.labelX6);
            this.pnlQuickAccess.Controls.Add(this.labelX4);
            this.pnlQuickAccess.Controls.Add(this.labelX3);
            this.pnlQuickAccess.Controls.Add(this.comboBox2);
            this.pnlQuickAccess.Controls.Add(this.labelX2);
            this.pnlQuickAccess.Controls.Add(this.labelX1);
            this.pnlQuickAccess.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlQuickAccess.Location = new System.Drawing.Point(0, 27);
            this.pnlQuickAccess.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlQuickAccess.Name = "pnlQuickAccess";
            this.pnlQuickAccess.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pnlQuickAccess.Size = new System.Drawing.Size(1200, 72);
            this.pnlQuickAccess.TabIndex = 18;
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.labelX6.Location = new System.Drawing.Point(1035, 15);
            this.labelX6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(149, 38);
            this.labelX6.TabIndex = 17;
            this.labelX6.Text = "شرکت فعال";
            this.labelX6.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.labelX4.Location = new System.Drawing.Point(45, 15);
            this.labelX4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(149, 38);
            this.labelX4.TabIndex = 16;
            this.labelX4.Text = "زمان جاری";
            this.labelX4.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.labelX3.Location = new System.Drawing.Point(200, 15);
            this.labelX3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(149, 38);
            this.labelX3.TabIndex = 15;
            this.labelX3.Text = "کاربر جاری";
            this.labelX3.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            this.comboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(355, 21);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBox2.Size = new System.Drawing.Size(149, 26);
            this.comboBox2.TabIndex = 14;
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.labelX2.Location = new System.Drawing.Point(510, 15);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(149, 38);
            this.labelX2.TabIndex = 13;
            this.labelX2.Text = "دوره فعال";
            this.labelX2.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.labelX1.Location = new System.Drawing.Point(665, 15);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(149, 38);
            this.labelX1.TabIndex = 11;
            this.labelX1.Text = "سیستم فعال";
            this.labelX1.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // pnlSidebar
            // 
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            this.pnlSidebar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSidebar.Controls.Add(this.btnSide_Alarm);
            this.pnlSidebar.Controls.Add(this.btnSide_Markaz);
            this.pnlSidebar.Controls.Add(this.labelX5);
            this.pnlSidebar.Controls.Add(this.btnSide_Logout);
            this.pnlSidebar.Controls.Add(this.btnSide_Setting);
            this.pnlSidebar.Controls.Add(this.btnSide_Security);
            this.pnlSidebar.Controls.Add(this.btnSide_Years);
            this.pnlSidebar.Controls.Add(this.btnSide_Company);
            this.pnlSidebar.Controls.Add(this.lblTitle);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlSidebar.Location = new System.Drawing.Point(980, 99);
            this.pnlSidebar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Size = new System.Drawing.Size(220, 782);
            this.pnlSidebar.TabIndex = 19;
            // 
            // btnSide_Alarm
            // 
            this.btnSide_Alarm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Alarm.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Alarm.Location = new System.Drawing.Point(3, 529);
            this.btnSide_Alarm.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Alarm.Name = "btnSide_Alarm";
            this.btnSide_Alarm.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Alarm.TabIndex = 13;
            this.btnSide_Alarm.Text = "یادآور";
            this.btnSide_Alarm.UseVisualStyleBackColor = false;
            // 
            // btnSide_Markaz
            // 
            this.btnSide_Markaz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Markaz.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Markaz.Location = new System.Drawing.Point(3, 298);
            this.btnSide_Markaz.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Markaz.Name = "btnSide_Markaz";
            this.btnSide_Markaz.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Markaz.TabIndex = 12;
            this.btnSide_Markaz.Text = "مرکز هزینه";
            this.btnSide_Markaz.UseVisualStyleBackColor = false;
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX5.ForeColor = System.Drawing.Color.White;
            this.labelX5.Location = new System.Drawing.Point(1, 61);
            this.labelX5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(210, 39);
            this.labelX5.TabIndex = 11;
            this.labelX5.Text = "سیستم یکپارچه سزار";
            this.labelX5.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // btnSide_Logout
            // 
            this.btnSide_Logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Logout.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Logout.ForeColor = System.Drawing.Color.Red;
            this.btnSide_Logout.Location = new System.Drawing.Point(3, 606);
            this.btnSide_Logout.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Logout.Name = "btnSide_Logout";
            this.btnSide_Logout.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Logout.TabIndex = 10;
            this.btnSide_Logout.Text = "خروج";
            this.btnSide_Logout.UseVisualStyleBackColor = false;
            // 
            // btnSide_Setting
            // 
            this.btnSide_Setting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Setting.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Setting.Location = new System.Drawing.Point(3, 452);
            this.btnSide_Setting.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Setting.Name = "btnSide_Setting";
            this.btnSide_Setting.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Setting.TabIndex = 9;
            this.btnSide_Setting.Text = "تنظیمات سیستم";
            this.btnSide_Setting.UseVisualStyleBackColor = false;
            // 
            // btnSide_Security
            // 
            this.btnSide_Security.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Security.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Security.Location = new System.Drawing.Point(3, 375);
            this.btnSide_Security.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Security.Name = "btnSide_Security";
            this.btnSide_Security.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Security.TabIndex = 8;
            this.btnSide_Security.Text = "پشتیبانی و امنیت";
            this.btnSide_Security.UseVisualStyleBackColor = false;
            // 
            // btnSide_Years
            // 
            this.btnSide_Years.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Years.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Years.Location = new System.Drawing.Point(3, 221);
            this.btnSide_Years.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Years.Name = "btnSide_Years";
            this.btnSide_Years.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Years.TabIndex = 7;
            this.btnSide_Years.Text = "سال مالی";
            this.btnSide_Years.UseVisualStyleBackColor = false;
            // 
            // btnSide_Company
            // 
            this.btnSide_Company.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.btnSide_Company.Font = new System.Drawing.Font("A Iranian Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSide_Company.Location = new System.Drawing.Point(3, 144);
            this.btnSide_Company.Margin = new System.Windows.Forms.Padding(4);
            this.btnSide_Company.Name = "btnSide_Company";
            this.btnSide_Company.Size = new System.Drawing.Size(210, 75);
            this.btnSide_Company.TabIndex = 6;
            this.btnSide_Company.Text = "اطلاعات شرکت";
            this.btnSide_Company.UseVisualStyleBackColor = false;
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            // 
            // 
            // 
            this.lblTitle.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(1, 12);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(210, 39);
            this.lblTitle.TabIndex = 5;
            this.lblTitle.Text = "Cizar ERP";
            this.lblTitle.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(97)))), ((int)(((byte)(109)))));
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(821, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBox1.Size = new System.Drawing.Size(208, 26);
            this.comboBox1.TabIndex = 18;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(1200, 881);
            this.Controls.Add(this.pnlSidebar);
            this.Controls.Add(this.pnlQuickAccess);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("A Iranian Sans", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "داشبورد سزار";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlQuickAccess.ResumeLayout(false);
            this.pnlSidebar.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem حسابداریمالیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خزانهداریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خریدوفروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حقوقودستمزدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مبانیاولیهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مبانیحقوقیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عملیاتماهانهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پشتیبانیوامنیتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتحقوقودستمزدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مبانیمحاسبهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیبانکToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفمزایاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفوامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفمرخصیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حکمحقوقیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جدولمالیاتیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عناوینشغلیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مبانیمحاسبهToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem معرفیپرسنلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ردیفپیمانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حکمحقوقیToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ثبتوامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتبیمهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتکارکردToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem محاسبهحقوقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem محاسبهمزایایپایانسالToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فیشحقوقیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستحقوقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستبانکToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستبیمهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستمالیاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اطلاعاتپرسنلیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستخامکارکردToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تهیهپشتیبانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بازیابیپشتیبانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجازسیستمToolStripMenuItem;
        private System.Windows.Forms.Panel pnlQuickAccess;
        private System.Windows.Forms.Panel pnlSidebar;
        public System.Windows.Forms.Button btnSide_Company;
        public System.Windows.Forms.Button btnSide_Logout;
        public System.Windows.Forms.Button btnSide_Setting;
        public System.Windows.Forms.Button btnSide_Security;
        public System.Windows.Forms.Button btnSide_Years;
        private System.Windows.Forms.ToolStripMenuItem تعریفمبالغمزایایسالیانهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفینحوهمحاسبهمالیاتToolStripMenuItem;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX3;
        private System.Windows.Forms.ComboBox comboBox2;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX lblTitle;
        private System.Windows.Forms.ToolStripMenuItem خلاصهگزارشحقوقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشکارکردToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشمرخصیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیضرایببیمهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سندافتتاحیهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سندحسابداریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستاسنادToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem بستنحسابهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سندسودوزیانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سنداختتامیهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem صورتحسابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ترازآزمایشیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سودوزیانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ترازنامهToolStripMenuItem;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private System.Windows.Forms.ToolStripMenuItem مبانیاولیهToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem گروهبندیحسابهاToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem کلومعینToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیحسابتفصیلیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پشتیبانیوامنیتToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem مبانیاولیهToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem عملیاتپرداختToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عملیاتدریافتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عملیاتپرداختودریافتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem پشتیبانیوامنیتToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem معرفیبانکToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem معرفیصندوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیتنخواهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیدستهچکToolStripMenuItem;
        public System.Windows.Forms.Button btnSide_Markaz;
        public System.Windows.Forms.Button btnSide_Alarm;
        private System.Windows.Forms.ToolStripMenuItem مبانیاولیهToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem فاکتوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem برگشتازخریدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem برگشتازفروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem گروهبندیکالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem معرفیواحدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گروهبندیکالاToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem تعیینسرفصلهایحسابداریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتخریدوفروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پشتیبانیوامنیتToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتحسابداریمالیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تنظیماتخزانهداریToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}