﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cizar.ERP
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private bool isFullScreen = false;
        private Rectangle normalBounds;

        private void frmMain_Load(object sender, EventArgs e)
        {
            

            // تنظیم سایز تقریباً فول‌اسکرین (10px کمتر از صفحه)
            int margin = 5;
            this.Bounds = new Rectangle(
                margin,
                margin,
                Screen.PrimaryScreen.Bounds.Width - (2 * margin),
                Screen.PrimaryScreen.Bounds.Height - (2 * margin)
            );

            
            pnlSidebar.Width = 220;
            pnlSidebar.Location = new Point(this.ClientSize.Width - 230, 0); // 230 = 220 (عرض پنل) + 10 (فاصله)
          

            // اختیاری: اگر می‌خوای بُردِر دور پنل دیده بشه
            pnlSidebar.BorderStyle = BorderStyle.Fixed3D; // یا Fixed3D




        }

    }
}
